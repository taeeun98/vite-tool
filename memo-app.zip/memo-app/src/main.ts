
import { handleDragEnd, handleDragOver, handleDelete, handleDragStart, handleOpenPop, handleCreate, handleClosePop  } from './handler';
import { fetchMemo } from './service/service';
import '/src/style.css';



export const main = document.querySelector('main') as HTMLElement;

const create = document.querySelector('.create') as HTMLButtonElement;
const done = document.querySelector('.done') as HTMLButtonElement;
const close = document.querySelector('.close') as HTMLButtonElement;




window.addEventListener('DOMContentLoaded',()=>{
  fetchMemo();
})

main.addEventListener('dragstart',handleDragStart);
main.addEventListener('dragover',handleDragOver);
main.addEventListener('dragend',handleDragEnd);
main.addEventListener('click', handleDelete);
// 이거 handleDelete 같은 거 사용하고 있는부분 안타고 가지는데 원래 그런가여?


create.addEventListener('click', handleOpenPop);
done.addEventListener('click', handleCreate);
close.addEventListener('click', handleClosePop);
